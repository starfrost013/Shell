﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Shell.UI
{
    partial class ShellXML
    {
        // Operation code

        List<string> OperandList;

        List<char> OpList;


        public ShxmlVariable ShxmlPerformOperation(XmlNode token)
        {
            XmlAttributeCollection attributes = token.Attributes;
            ShxmlVariable var = new ShxmlVariable();

            OperandList = new List<string>();
            OpList = new List<char>();

            

            foreach (XmlAttribute attribute in attributes)
            {
                if (attribute.Name == "op")
                {
                    char[] whatwerecuttingout = { '+', '-', '*', '/' };
                    StringBuilder thestringsurgeon = new StringBuilder();
                    //string[] thebits = attribute.Value.Split(whatwerecuttingout);
                    char[] thebits = attribute.Value.ToCharArray();
                    int count = 0;
                    foreach (char bit in thebits)
                    {
                       switch (bit)
                        {
                            case '+':
                            case '-':
                            case '*':
                            case '/':
                                OpList.Add(bit);
                                continue;
                        }
                    count++;
                    }

                }

                if (attribute.Name == "var") // a
                {
                    var.Name = attribute.Value;
                }
            }

            return var;
        }

    }
}
