﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Shell.UI
{
    partial class ShellUI
    {
        public void ShxmlHandleIfStatement(XmlNode token) // v0.5.6+
        {
            XmlAttributeCollection attributes = token.Attributes; // no attributes but yeahhhhhhhhhhhhhhhhhhhhhhhhh

            if (!token.HasChildNodes)
            {
                ShellCore.ElmThrowException(33); //Empty if statement

            }

            ShXML.ShxmlEvaluateStatement(token, 1);

            return;
        }
    }
}
