﻿using Shell.Core;
using Shell.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Shell
{
    class Shell
    {
        public static Shell Shl { get; set; } 
        public static ShellCore ShellCore { get; set; }

        public static ShellUI ShellUI { get; set; }

        public string DefaultMenuPath { get; set; }

        // Main Shell code. Nothing here yet.
        [STAThread] // unfortunately we have to use this
        static void Main(string[] args) // shell main
        {
            Shl = new Shell();
            
            int init_result = Shl.Init(args);
            if (init_result == 1)
            {
                Console.WriteLine("Error Code CRITICAL-001: ShellCore/ShellUI Initalization Failed. Shell cannot start. Press any key to exit.");
                Console.ReadKey();
                ShellCore.Exit(0); 

            }
           
        }
        
        internal int Init(string[] args) // initalizes the shell
        {
            ShellCore = new ShellCore();
            ShellUI = new ShellUI();
            ShellCore.InitShellCore();
            ShellCore.ElmInitExceptionManager();
            ShellCore.ShlWriteLog("Test.txt","test.");
            ShellUI.InitShellUI();
            Console.Clear(); // so we can do stuff
            

            ShellCore.ShlHandleCmdArguments(args); // universal arguments (config - user name...)
            // SHELL MAIN ARGUMENTS
            if (args.Length > 0) // if there's an argument
            {
                // we only support 1 argument so no need for for/switch loop
                ShellUI.XmlParseScript(args[0]);
                Console.WriteLine("Script has completed. Press enter to exit.");
                Console.ReadKey();
                ShellCore.Exit(0);
            }

            if (ShellCore == null || ShellUI == null)
            {
                return 1;
            }

            Console.WriteLine("Shell Development Release");
            Console.WriteLine("Version: 0.2.8.0\n");
            Console.WriteLine("Dependency Versions:");

            FileVersionInfo shellcore_ver = ShellCore.GetVersion();
            FileVersionInfo shellui_ver = ShellUI.GetVersion();
            ShellCore.ShlSetWindowTitle($"Shell - core ver {shellcore_ver.FileMajorPart}.{shellcore_ver.FileMinorPart}.{shellcore_ver.FileBuildPart}.{shellcore_ver.FilePrivatePart}.");

            Console.WriteLine($"ShellCore Version: {shellcore_ver.FileMajorPart}.{shellcore_ver.FileMinorPart}.{shellcore_ver.FileBuildPart}.{shellcore_ver.FilePrivatePart}");
            Console.WriteLine($"ShellUI Version: {shellui_ver.FileMajorPart}.{shellui_ver.FileMinorPart}.{shellui_ver.FileBuildPart}.{shellui_ver.FilePrivatePart}\n");

            //Console.WriteLine("*** SHELLCORE WARNING: In Version 5.5, functions have been changed from using arrays of strings to collections of strings. Please update any applications that may be using ShellCore 2.x, 3.x, 4.x, or 5.0. ***\n");

            ShellUI.XmlParseScript("TestMenuV3.xml");


            foreach (ShxmlVariable ShxmlVar in ShellUI.ShXML.Varlist)
            {
                switch (ShxmlVar.Type)
                {
                    case 0:
                        Console.WriteLine($"Variable: Name = {ShxmlVar.Name}. Value = {ShxmlVar.varint}. Type = Int.");
                        continue;
                    case 1:
                        Console.WriteLine($"Variable: Name = {ShxmlVar.Name}. Value = {ShxmlVar.varstring}. Type = String.");
                        continue;
                    case 2:
                        Console.WriteLine($"Variable: Name = {ShxmlVar.Name}. Value = {ShxmlVar.varchar}. Type = Char.");
                        continue;
                    case 3:
                        Console.WriteLine($"Variable: Name = {ShxmlVar.Name}. Value = {ShxmlVar.vardouble}. Type = Double.");
                        continue;
                    case 4:
                        Console.WriteLine($"Variable: Name = {ShxmlVar.Name}. Value = {ShxmlVar.varfloat}. Type = Float.");
                        continue;
                    case 5:
                        Console.WriteLine($"Variable: Name = {ShxmlVar.Name}. Value = {ShxmlVar.varbool}. Type = Boolean.");
                        continue;

                }

            }
            
            Console.ReadKey();
            return 0;

        }

    }
}
