﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Core
{
    partial class ShellCore
    {
		// ATTN: We are missing Registry.DynData, but DynData is ONLY ON WINDOWS 9X!!!!!! So do not add it.
		public bool WinCreateRegKey(int root, string thePath)
        {
            try
            {
                switch (root)
                {
                    case 0:
                        Registry.ClassesRoot.CreateSubKey(thePath); // HKEY_CLASSES_ROOT
                        return true;
                    case 1:
                        Registry.LocalMachine.CreateSubKey(thePath); // HKEY_LOCAL_MACHINE
                        return true;
                    case 2:
                        Registry.Users.CreateSubKey(thePath); // HKEY_USERS
                        return true;
                    case 3:
                        Registry.CurrentUser.CreateSubKey(thePath); // HKEY_CURRENT_USER
                        return true;
                    case 4:
                        Registry.CurrentConfig.CreateSubKey(thePath); // HKEY_CURRENT_CONFIG
                        return true;
                    case 5:
                        Registry.PerformanceData.CreateSubKey(thePath); // HKEY_PERFORMANCE_DATA
                        return true;
                    default:
                        ElmThrowException(34);
                        return false;
                }
            }
            catch (UnauthorizedAccessException)
            {
                ElmThrowException(36);
                return false;
            }
            catch (System.Security.SecurityException)
            {
                ElmThrowException(37);
                return false;
            }
            catch (ArgumentException)
            {
                ElmThrowException(39);
                return false;
            }
        }

		public bool WinDeleteRegKey(int root, string thePath)
        {
            try
            {
                switch (root)
                {
                    case 0:
                        Registry.ClassesRoot.DeleteSubKey(thePath); // HKEY_CLASSES_ROOT
                        return true;
                    case 1:
                        Registry.LocalMachine.DeleteSubKey(thePath); // HKEY_LOCAL_MACHINE
                        return true;
                    case 2:
                        Registry.Users.DeleteSubKey(thePath); // HKEY_USERS
                        return true;
                    case 3:
                        Registry.CurrentUser.DeleteSubKey(thePath); // HKEY_CURRENT_USER
                        return true;
                    case 4:
                        Registry.CurrentConfig.DeleteSubKey(thePath); // HKEY_CURRENT_CONFIG
                        return true;
                    case 5:
                        Registry.PerformanceData.DeleteSubKey(thePath); // HKEY_PERFORMANCE_DATA
                        return true;
                    default:
                        ElmThrowException(35);
                        return false;
                }
            }
			catch (UnauthorizedAccessException) // access denied by OS
            {
                ElmThrowException(36);
                return false;
            }
			catch (System.Security.SecurityException) // security exception
            {
                ElmThrowException(37);
                return false;
            }
			catch (ArgumentException) // argument exception
            {
                ElmThrowException(38);
                return false;
            }
			

        }

        public object WinGetRegValue(string keyPath, string valuePath, object defaultValue)
        {
            try
            {
                var RegValue = Registry.GetValue(keyPath, valuePath, defaultValue);
                return RegValue;
            }

            catch (UnauthorizedAccessException) // access denied by OS
            {
                ElmThrowException(36);
                return false;
            }
            catch (System.Security.SecurityException) // security exception
            {
                ElmThrowException(37);
                return false;
            }
            catch (ArgumentException) // argument exception
            {
                ElmThrowException(42);
                return false;
            }
        }


        public bool WinSetRegValue(string keyPath, string valuePath, object value, RegistryValueKind type)
        {
            try {
                Registry.SetValue(keyPath, valuePath, value, type);
                return true;
            }

            catch (UnauthorizedAccessException) // access denied by OS
            {
                ElmThrowException(36);
                return false;
            }
            catch (System.Security.SecurityException) // security exception
            {
                ElmThrowException(37);
                return false;
            }
            catch (ArgumentException) // argument exception
            {
                ElmThrowException(42);
                return false;
            }
        }
       
    }
}
