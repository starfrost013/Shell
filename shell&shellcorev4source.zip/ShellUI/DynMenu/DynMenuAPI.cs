﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shell.Core;
namespace Shell.UI // Dynamic Text UI
{
    internal enum Days { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday };
    
    public partial class DynMenuAPI  // Internal only.
    {
        public void DrawBlankSpace(int amount)
        {
            int i = 0;

            for (i = 0; i < amount; i++)
            {
                Console.Write("");
                return;
                
            }
        }

        public int SetConsoleColour(ConsoleColor foregroundColour, ConsoleColor backgroundColour)
        {
            ConsoleColor[] Colours = (ConsoleColor[])ConsoleColor.GetValues(typeof(ConsoleColor)); // enumerate through everything

            foreach (ConsoleColor colour in Colours)
            {
                Console.WriteLine(colour);
                if (colour == foregroundColour)
                {
                    Console.ForegroundColor = colour;
                }
            }

            return 0;
       
        }


    }
    
}
