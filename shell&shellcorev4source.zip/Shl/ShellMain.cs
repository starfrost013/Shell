﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shell.Core;
using Shell.UI;

namespace Shell
{
    class Shell 
    {
        // Main Shell code. Nothing here yet.
        static void Main(string[] args)
        {
        }
    }
}
