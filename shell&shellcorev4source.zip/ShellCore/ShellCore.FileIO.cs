﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Core
{
    partial class ShellCore 
    {
        public bool CreateFileEx(string path, string initialContent=null, bool verifyThatNotAlreadyExist = false) // Create File for 2.6 and up
        {
            if (verifyThatNotAlreadyExist == true)
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                }
            }
            else
            {
                File.Create(path);
            }

            if (initialContent != null) // if we want to create the file
            {
                try
                {
                    File.OpenWrite(path);
                    File.AppendText(initialContent);
                }
                catch (FileNotFoundException err)
                {
                    return false; // we failed
                }
                catch (DirectoryNotFoundException err)
                {
                    return false; // we failed
                }

            }

            return true;
            }
            
        public bool DeleteFileEx(string path, bool askUserConsoleOnly = false, string confirmationMessage="Are you sure you want to delete") // Delete File for 2.6+
        {
            if (askUserConsoleOnly == true)
            {
                bool loopAsk = true;
                while (loopAsk == true) // deleteFile
                {
                    Console.WriteLine($"{confirmationMessage} {path} [Y/N]?");
                    string result = Console.ReadLine();
                    switch (result)
                    {
                        case "n":
                        case "N":
                        case "y":
                        case "Y":
                            loopAsk = false;
                            break; // stop the looping!
   
                    }

                }

                
            }

            
            return true;
        }

        public bool CopyFileEx(string oldpath, string newpath, bool operationSuccessfulMessageConsoleOnly = false, string operationSuccessfulMessage = "The file was successfully copied to")
        {   try
            {
                File.Copy(oldpath, newpath);
            }

            catch (FileNotFoundException err)
            {
                return false; // we failed
            }

            catch (DirectoryNotFoundException err)
            {
                return false; // we failed
            }

            catch (UnauthorizedAccessException err)
            {
                return false; // we failed
            }

            if (operationSuccessfulMessageConsoleOnly == false)
            {
                Console.WriteLine($"{operationSuccessfulMessage} {newpath} ");
            }

            return true;
        }

        public bool MoveFileEx(string oldpath, string newpath, bool operationSuccessfulMessageConsoleOnly = false, string operationSuccessfulMessage = "The file was successfully moved to")
        {
            try
            {
                File.Move(oldpath, newpath);
            }

            catch (FileNotFoundException err)
            {
                return false; // we failed
            }

            catch (DirectoryNotFoundException err)
            {
                return false; // we failed
            }

            catch (UnauthorizedAccessException err)
            {
                return false; // we failed
            }

            if (operationSuccessfulMessageConsoleOnly == false)
            {
                Console.WriteLine($"{operationSuccessfulMessage} {newpath} ");
            }

            return true;
        }

        public bool VerifyExistence(string path) // Checks if a file exists
        {
            if (File.Exists(path))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteFileEx(string path) // Delete a file - v3.0b plus
        {
            if (File.Exists(path))
            {
                File.Delete(path);
                return true;
            }

            else
            {
                return false; // The file was not found.
            }
        }
    }
}
