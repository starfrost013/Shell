﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// TODO: rename this
namespace Shell.Core
{
    partial class ShellCore : IUsefulLibrary
    { 
        public int[] GetVersion()  
        {
            int[] Version = { 4, 0, 0, 0 };

            return Version;
        }

    }
}
