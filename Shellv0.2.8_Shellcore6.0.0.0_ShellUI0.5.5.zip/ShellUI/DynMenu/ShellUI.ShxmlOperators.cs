﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Shell.UI
{
    partial class ShellXML
    {
        // Operation code

        List<string> OperandList;

        List<char> OpList;

        string[] cleancut;

        public ShxmlVariable ShxmlPerformOperation(XmlNode token)
        {

            int count = 0;
            double result = 0;

            XmlAttributeCollection attributes = token.Attributes;
            ShxmlVariable svar = new ShxmlVariable();

            OperandList = new List<string>();
            OpList = new List<char>();
            foreach (XmlAttribute attribute in attributes)
            {
                if (attribute.Name == "op")
                {
                    //string[] thebits = attribute.Value.Split(whatwerecuttingout);
                    char[] thebits = attribute.Value.ToCharArray();

                    // This works because the first operand is after the first part of the string. Thus we get the correct operands.
                    foreach (char bit in thebits)
                    {
                       switch (bit)
                        {
                            case '+':
                            case '-':
                            case '*':
                            case '/':
                            case '%':
                                OpList.Add(bit);
                                continue;
                        }
                        count++;
                    }

                    // convert the operator* list (not operand) to an 
                    char[] OperatorListA = OpList.ToArray(); // convert to array
                    cleancut = attribute.Value.Split(OperatorListA);
                    
                    count = 0; // reset the count

                    foreach (string bit2 in cleancut)
                    {
                        foreach (ShxmlVariable shvar in Varlist)
                        {
                            if (cleancut[count] == shvar.Name)
                            {
                                if (shvar.Type == 1)
                                {
                                    ShellCore.ElmThrowException(14); // Can't do stuff to strings...yet. 
                                }

                                else if (shvar.Type == 5)
                                {
                                    ShellCore.ElmThrowException(15); // Can't add booleans.
                                }

                                else
                                {
                                    OperandList.Add(Convert.ToString(shvar.vardouble)); // convert it to string
                                    count++;
                                    continue;
                                }
                            }
                        
                        }
                        OperandList.Add(bit2);
                        count++;
                    }

                }

                if (attribute.Name == "var") // a
                {
                    svar.Name = attribute.Value;
                    svar.Type = 3; // double by default
                }

                List<ShxmlVariable> vars = new List<ShxmlVariable>();
                List<double> bit3 = new List<double>();
                List<double> bit3c = new List<double>();

                count = 0; //set count back to 0
                foreach (string bit2 in cleancut)
                {
                    string bit2a = bit2.Trim();

                    int isVar = 0;
                    foreach (ShxmlVariable sxvar in Varlist)
                    {
                        if (sxvar.Name == bit2a)
                        {
                            isVar = 1;
                            vars.Add(sxvar);
                            bit3.Add(sxvar.vardouble);
                        }

                    }
                    if (isVar == 0)
                    {
                        try
                        {
                            double bit2b = Convert.ToDouble(bit2a);
                            bit3.Add(bit2b);
                        }
                        catch (FormatException)
                        {
                            ShellCore.ElmThrowException(12); // non-numeric characters should've been detected before here (shellui 0.5+)
                        }
                    }
                    isVar = 0;

                }

                // so it's easier
                double[] bit3b = bit3.ToArray();
                
                ShxmlVariable[] varsb = vars.ToArray(); // local list converted to an array.

                // jesus fucking christ this code is getting worse!

                foreach (ShxmlVariable varsb2 in varsb)
                {
                    bit3c.Add(varsb2.vardouble);
                }

                // this actually parses the stuff
                foreach (double bit3a in bit3b)
                {

                    // This is awaiting changes to adding an overload in ShellCore to perform operations on a single int instead of a collection.
                    switch (OpList[count])
                    {
                        case '+':
                            //2d

                            result = bit3a + bit3b[count + 1];
                            continue;
                        case '-':
                            result = bit3a - bit3b[count + 1];
                            continue;
                        case '*':
                            result = bit3a * bit3b[count + 1];
                            continue;
                        case '/':
                            result = bit3a / bit3b[count + 1];
                            continue;
                        case '%':
                            result = bit3a % bit3b[count + 1];
                            continue;
                    }
                    count++;
                }

                count = 0;

                foreach (ShxmlVariable ShxVar in varsb)
                {
                    if (OpList.Count - count > 1)
                    {
                        switch (OpList[count])
                        {
                            case '+':
                                //2d

                                result = result + bit3c[count];
                                count++;
                                continue;
                            case '-':
                                result = result - bit3c[count];
                                count++;
                                continue;
                            case '*':
                                result = result * bit3c[count];
                                count++;
                                continue;
                            case '/':
                                result = result / bit3c[count];
                                count++;
                                continue;
                            case '%':
                                result = result % bit3c[count];
                                count++;
                                continue;
                        }
                    }
                }

                count = 0;
                //update the main list
                
            }
            svar.vardouble = result;
            Varlist.Add(svar);

            return svar;
        }
    }
}
