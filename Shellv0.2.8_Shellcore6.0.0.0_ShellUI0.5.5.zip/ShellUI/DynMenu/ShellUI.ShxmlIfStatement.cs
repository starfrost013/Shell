﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.UI
{
    partial class ShellUI
    {
        public void ShxmlHandleIfStatement() // v0.5.5+ (if)
        {
            ShellCore.ElmThrowException(25);
            return;
        }
    }
}
