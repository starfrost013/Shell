﻿using Shell;
using Shell.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
namespace Shell.UI
{
    partial class ShellUI : IShell
    {
        public ShellXML ShXML { get; set; }
        public int XmlParseScript(string path, int isFunction = 0, int isStatement = 0)
        {

            if (isFunction != 0) // call it 
            {
                Console.WriteLine($"Parsing ShellXML function at {path}...\n");
            }
            else
            {
                Console.WriteLine($"Parsing ShellXML script at {path}...\n");
            }

            XmlDocument script = new XmlDocument();

            try
            {
                script.Load(path);
            }

            catch (FileNotFoundException)
            {
                ShellCore.ElmThrowException(13);
            }

            catch (DirectoryNotFoundException)
            {
                ShellCore.ElmThrowException(13);
            }

            catch (XmlException)
            {
                ShellCore.ElmThrowException(10);
            }

            
            XmlNode script_root = script.FirstChild;

            if (script_root.Name != "ShellXML")
            {
                ShellCore.ElmThrowException(3); // throw an exception if the shellxml node isn't there
            }

            XmlNodeList ScriptTokens;

            if (!script_root.HasChildNodes)
            {
                ShellCore.ElmThrowException(4); // nothing
                return 5;

            } else
            {
                ScriptTokens = script_root.ChildNodes;
            }
            

            //int rootElementCount = 0;

            foreach (XmlNode token in ScriptTokens)
            {
                switch (token.Name)
                {
                    default:
                        ShellCore.ElmThrowException(0);
                        return 2;
                    case "#document":
                        continue;
                    case "#comment":
                        continue;
                    case "shellxml":
                    case "Shellxml":
                    case "shellXML":
                    case "ShellXML":
                        ShellCore.ElmThrowException(3);
                        return 4;
                    case "var":
                    case "Var":
                        ShXML.ShxmlDeclareVariable(token);
                        continue;
                    case "operation":
                    case "Operation":
                    case "op":
                    case "Op":
                        ShXML.ShxmlPerformOperation(token);
                        continue;
                    case "input":
                    case "Input":
                        ShXML.ShxmlConsoleInput(token);
                        continue;
                    case "output":
                    case "Output":
                        ShXML.ShxmlConsoleOutput(token);
                        continue;
                    case "function":
                    case "Function":
                        string fpath = ShXML.ShxmlRunFunction(token);
                        XmlParseScript(fpath,1);
                        continue;
                        
                  }
            }
            return 0;
        }

    }

    public partial class ShellXML : ShellUI
    {
        public List<Keyword> KeywordList { get; set; }
        // old code removed

        public Keyword UiScAddKeyword(string keywordName, string[] attributes) // add a keyword
        {
            Keyword _ = new Keyword();

            if (KeywordList == null)
            {
                return _; 
            }

            _.keywordName = keywordName;
            _.Attributes = attributes;
            KeywordList.Add(_);
            return _;
        }


    }

    public struct Keyword
    {
        public string keywordName { get; set; }

        public string[] Attributes { get; set; }

    }

}
