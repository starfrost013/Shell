﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Core
{
    partial class ShellCore
    {
        public int Debug { get; set; }

        public string LogPath { get; set; }

        public FileStream logStream { get; set; }

        public StreamWriter streamWriter { get; set; }

        public void InitShellCore()
        {
            this.ElmInitialized = 0;
            this.Pi = Math.PI;
            this.E = Math.E;
            this.C = 299792458;
            this.Debug = 1;
        }

        public void ExecuteFileEx(string executePath, List<string> arg)
        {
            foreach (string argument in arg)
            {
                if (argument.Contains('\'')) ;
                {
                    ElmThrowException(9); // Exception 9 - Shell does not support that character in strings as it could be confused for \n.
                }

            }

            StringBuilder FinalShutdownString = new StringBuilder(executePath);

            foreach (string argument in arg)
            {
                FinalShutdownString.Append($" {argument}");
            }

            Console.WriteLine(FinalShutdownString);


        }

        public void Exit(int exitCode)
        {
            ShlCloseLog();
            Environment.Exit(exitCode);
        }


        public List<int> GetVersion()
        {
            List<int> Version = new List<int> { 6, 0, 0, 0 };

            return Version;
        }

        public void PrintVersion() // 5.7+
        {
            List<int> version = GetVersion();
            Console.WriteLine($"{version[0]}.{version[1]}.{version[2]}.{version[3]}");
        }

        public void ShlBeep(Nullable<int> frequency = null, Nullable<int> length = null) // 6.0+ - plays a beep noise. Is not compatible with Windows XP x64 Edition and 64-bit Windows Vista.
        {
            if (frequency == null || length == null)
            {
                Console.Beep();
                return;
            }

            Console.Beep(Convert.ToInt32(frequency), Convert.ToInt32(length)); // convert from int32? to int32. 
            return;
        }


        //public void 
        public void ShlHandleCmdArguments(string[] args)
        {
            if (args.Length > 0)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    string thearg = args[i];
                    
                    switch (thearg)
                    {
                        case "configlocation":
                            ElmThrowException(24);
                            continue;
                        default:
                            continue;
                    }

                }

             }
             return;

        }

        internal int ShlHardError(string Message, int errorCode) // Used for critical errors where we can't use ExceptionsLite.
        {
            Console.WriteLine("Critical Error\n");
            Console.WriteLine($"CRITICAL-{errorCode}. {Message}. Shell must exit. There is a bug in the Shell which has forced it into a critical unfixable state. You must update or reinstall Shell. ");
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
            Environment.Exit(0xD15EA5E + errorCode);
            return 0;
        }

        public void ShlSetWindowTitle(string WindowTitle) //set the window title
        {
            Console.Title = WindowTitle;
            return;
        }


        public void ShlWriteLog(string path, string text)
        {

            if (!File.Exists(path) & Debug == 1)
            {
                try
                {
                    File.Create(path);
                }
                catch (DirectoryNotFoundException)
                {
                    ElmThrowException(32);
                    return;
                }
            }

            else if (File.Exists(path) & Debug == 1) // if debug is on and the file exists
            {
                try
                {
                    this.logStream = File.Open(path, FileMode.Open); // poen the file
                    this.streamWriter = new StreamWriter(logStream);
                    streamWriter.WriteLine(text);
                    ShlCloseLog();
                    LogPath = path;
                }
                catch (IOException)
                {
                    ElmThrowException(29);
                    return;
                }
            }
        }


        public void ShlCloseLog()
        {
            this.streamWriter.Close(); // close the stream writer
            this.logStream.Close(); // close the stream
        }

        //TODO: Change from string arrays to collections of strings for these functions in version 5.5. This will be the last function created with it. 
        public void ShlPowerControl(List<string> arg) // power control utilizing ExecuteFileEx
        {
            // FOR LATER USE // List<string> args = new List<string>(); // FOR LATER USE //

            foreach (string argument in arg)
            {
                switch (argument)
                {
                    // Special handling for arguments.
                    case "-i":
                        if (arg[0] != "-i")
                        {
                            ElmThrowException(8);
                        }
                        continue;

                }

            }

            ExecuteFileEx("shutdown", arg);
        }

        


    }
}
