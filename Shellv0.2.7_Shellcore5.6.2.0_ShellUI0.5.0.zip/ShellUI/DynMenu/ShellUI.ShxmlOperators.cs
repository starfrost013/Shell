﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Shell.UI
{
    partial class ShellXML
    {
        // Operation code

        List<string> OperandList;

        List<char> OpList;

        string[] cleancut;

        public ShxmlVariable ShxmlPerformOperation(XmlNode token)
        {

            int count = 0;
            double result = 0;

            XmlAttributeCollection attributes = token.Attributes;
            ShxmlVariable svar = new ShxmlVariable();

            OperandList = new List<string>();
            OpList = new List<char>();
            foreach (XmlAttribute attribute in attributes)
            {
                if (attribute.Name == "op")
                {
                    //string[] thebits = attribute.Value.Split(whatwerecuttingout);
                    char[] thebits = attribute.Value.ToCharArray();

                    // This works because the first operand is after the first part of the string. Thus we get the correct operands.
                    foreach (char bit in thebits)
                    {
                       switch (bit)
                        {
                            case '+':
                            case '-':
                            case '*':
                            case '/':
                                OpList.Add(bit);
                                continue;
                        }
                        count++;
                    }

                    // convert the operator* list (not operand) to an 
                    char[] OperatorListA = OpList.ToArray(); // convert to array
                    cleancut = attribute.Value.Split(OperatorListA);
                    
                    count = 0; // reset the count

                    foreach (string bit2 in cleancut)
                    {
                        foreach (ShxmlVariable shvar in Varlist)
                        {
                            if (cleancut[count] == shvar.Name)
                            {
                                if (shvar.Type == 1)
                                {
                                    ShellCore.ElmThrowException(14); // Can't do stuff to strings...yet. 
                                }

                                else if (shvar.Type == 5)
                                {
                                    ShellCore.ElmThrowException(15); // Can't add booleans.
                                }

                                else
                                {
                                    OperandList.Add(bit2);
                                    count++;
                                    continue;
                                }
                            }
                        
                        }
                        OperandList.Add(bit2);
                        count++;
                    }

                }

                if (attribute.Name == "var") // a
                {
                    svar.Name = attribute.Value;
                    svar.Type = 3; // double by default
                }

                List<int> bit3 = new List<int>();

                count = 0; //set count back to 0
                foreach (string bit2 in cleancut)
                {
                    string bit2a = bit2.Trim();
                    try
                    {
                        int bit2b = Convert.ToInt32(bit2a);
                        bit3.Add(bit2b);
                    }
                    catch (FormatException)
                    {
                        ShellCore.ElmThrowException(12); // non-numeric characters should've been detected before here (shellui 0.5+)
                    }

                }

                int[] bit3b = bit3.ToArray();
                

                // this actually parses the stuff
                foreach (int bit3a in bit3b)
                {

                    // This is awaiting changes to adding an overload in ShellCore to perform operations on a single int instead of a collection.
                    switch (OpList[count])
                    {
                        case '+':
                            //2d
                            result = bit3a + bit3b[count + 1];
                            continue;
                        case '-':
                            result = bit3a - bit3b[count + 1];
                            continue;
                        case '*':
                            result = bit3a * bit3b[count + 1];
                            continue;
                        case '/':
                            result = bit3a / bit3b[count + 1];
                            continue;
                    }
                    count++;
                }
            }
            svar.vardouble = result;
            Varlist.Add(svar);

            return svar;
        }

    }
}
