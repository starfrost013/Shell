﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shell.Core;
using Shell.UI;

namespace Shell
{
    class Shell 
    {
        public ShellCore ShellCore { get; set; }

        public ShellUI ShellUI { get; set; }

        public string DefaultMenuPath { get; set; }

        // Main Shell code. Nothing here yet.
        static void Main(string[] args) // shell main
        {
            Shell Shell = new Shell();
            int init_result = Shell.Init();

            if (init_result == 1)
            {
                Console.WriteLine("Error 1: ShellCore/ShellUI Initalization Failed. Shell cannot start. Press any key to exit.");
                Console.ReadKey();
                Environment.Exit(1); 

            }
        }
        
        internal int Init() // initalizes the shell
        {
            this.ShellCore = new ShellCore();
            this.ShellUI = new ShellUI();

            if (ShellCore == null || ShellUI == null)
            {
                return 1;
            }

            ShellCore.ElmInitExceptionManager(); // initalize exceptionslite
            Console.WriteLine("Cosmo's Shell");
            Console.WriteLine("Version: 0.1.1.0\n");
            Console.WriteLine("Dependency Versions:");
            int[] shellcore_ver = ShellCore.GetVersion();
            Console.WriteLine($"ShellCore Version: {shellcore_ver[0]}.{shellcore_ver[1]}.{shellcore_ver[2]}.{shellcore_ver[3]}\n");
            Console.ReadKey();


            return 0;

        }
    }
}
