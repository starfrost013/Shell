﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Core
{
    partial class ShellCore
    {
        public void Exit(int exitCode)
        {
            Environment.Exit(exitCode);
        }

        public int[] GetVersion()
        {
            int[] Version = { 4, 2, 1, 0 };

            return Version;
        }

    }
}
