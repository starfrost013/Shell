﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
// TODO: rename this
namespace Shell.Core
{
    partial class ShellCore : IShell
    { 
        public ShellCore() // Shellcore Constructor
        {
            // This sets up ElmInitialized
        }

        // DWJHFKAHDAHSDJHADSHASDJASHSDAHJ
    }
}
