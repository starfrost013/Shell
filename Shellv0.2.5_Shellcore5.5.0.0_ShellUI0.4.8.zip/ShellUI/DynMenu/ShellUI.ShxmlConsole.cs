﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Threading.Tasks;

namespace Shell.UI
{
    partial class ShellXML
    {
        public void ShxmlConsoleOutput(XmlNode token) // pass
        {
            string text = "";
            int posx = -0xd15ea5e;
            int posy = -0xd15ea5e;
            XmlAttributeCollection attributes = token.Attributes;

            foreach (XmlAttribute attribute in attributes)
            {
                // check for what we want
                switch (attribute.Name)
                {
                    case "text":
                        text = attribute.Value;

                        if (text == "")
                        {
                            ShellCore.ElmThrowException(18);
                        }

                        continue;
                    case "posx":
                        try
                        {
                            if (posx == -0xd15ea5e)
                            {
                                posx = Convert.ToInt32(attribute.Value); // x position (in char cells from 0)
                            }
                        }

                        catch (FormatException)
                        {
                            ShellCore.ElmThrowException(16);
                        }

                        if (posx == -0xd15ea5e)
                        {
                            ShellCore.ElmThrowException(18);
                        }

                        continue;
                    case "posy":
                        try
                        {
                            if (posy == -0xd15ea5e)
                            {
                                posy = Convert.ToInt32(attribute.Value); // y position (in char cells from 0)
                            }
                        }

                        catch (FormatException)
                        {
                            ShellCore.ElmThrowException(17);
                        }

                        if (posy == -0xd15ea5e)
                        {
                            ShellCore.ElmThrowException(18);
                        }


                        continue;
                    default:
                        ShellCore.ElmThrowException(19);
                        continue;
                        

                }

            }
            UiSetCursorPosition(posx, posy);
            Console.WriteLine(text); // since we're not done...

            return;
        }

    }
}
