﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Shell.UI
{
    partial class ShellXML
    {
        // Operation code

        List<string> OperandList;

        List<char> OpList;


        public ShxmlVariable ShxmlPerformOperation(XmlNode token)
        {
            XmlAttributeCollection attributes = token.Attributes;
            ShxmlVariable var = new ShxmlVariable();

            OperandList = new List<string>();
            OpList = new List<char>();

            

            foreach (XmlAttribute attribute in attributes)
            {
                if (attribute.Name == "op")
                {
                    //string[] thebits = attribute.Value.Split(whatwerecuttingout);
                    char[] thebits = attribute.Value.ToCharArray();
                    int count = 0;

                    // This works because the first operand is after the first part of the string. Thus we get the correct operands.
                    foreach (char bit in thebits)
                    {
                       switch (bit)
                        {
                            case '+':
                            case '-':
                            case '*':
                            case '/':
                                OpList.Add(bit);
                                continue;
                        }
                        count++;
                    }

                    char[] OpListA = OpList.ToArray(); // convert to array
                    string[] cleancut = attribute.Value.Split(OpListA);
                    
                    count = 0; // reset the count

                    foreach (string bit2 in cleancut)
                    {
                        foreach (ShxmlVariable shvar in Varlist)
                        {
                            if (cleancut[count] == shvar.Name)
                            {
                                if (shvar.Type == 1)
                                {
                                    ShellCore.ElmThrowException(14); // Can't do stuff to strings...yet. 
                                }

                                else if (shvar.Type == 5)
                                {
                                    ShellCore.ElmThrowException(15); // Can't add booleans.
                                }

                                else
                                {
                                    OperandList.Add(bit2);
                                    count++;
                                    continue;
                                }
                            }
                        
                        }
                        OperandList.Add(bit2);
                        count++;
                    }

                }

                if (attribute.Name == "var") // a
                {
                    var.Name = attribute.Value;
                }
            }

            return var;
        }

    }
}
