﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Threading.Tasks;

namespace Shell.UI
{
    partial class ShellUI
    {
    }

    partial class ShellXML
    {
        public List<ShxmlVariable> Varlist;

        public int InitShellXML()
        {
            Varlist = new List<ShxmlVariable>();
            return 0;
        }

        public ShxmlVariable ShxmlDeclareVariable(string Name, XmlNode node) // Automatically determines the type. Internal?
        {
            ShxmlVariable xmlvar = new ShxmlVariable();
            xmlvar.Name = Name;
            XmlAttributeCollection XmlAttrs = node.Attributes;

            string var_type = null;
            string var_value = null;

            foreach (XmlAttribute Attribute in XmlAttrs)
            {

                // get it!
                if (Attribute.Name == "type")
                {
                    var_type = Attribute.Value;
                }

                if (Attribute.Name == "value")
                {
                    var_value = Attribute.Value;
                }
                
            }

            if (var_type == null)
            {
                ShellCore.ElmThrowException(6);
            }
            try
            {
                switch (var_type)
                {
                    case "int":
                    case "Int":
                    case "number":
                    case "Number":
                        xmlvar.varint = Convert.ToInt32(var_value);
                        return xmlvar;
                    default:
                        ShellCore.ElmThrowException(5);
                        return xmlvar;

                }
            }
            catch (FormatException)
            {
                ShellCore.ElmThrowException(7);
                return xmlvar;
            }
            //return xmlvar;
            
        }


    }

    public struct ShxmlVariable
    {
        public string Name { get; set; }

        public int varint { get; set; } // this could be done better (delegates?)

        public string varstring { get; set; }

        public float varfloat { get; set; }

        public double vardouble { get; set; }

        public char varchar { get; set; } 


    }


}
