﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
// TODO: rename this
namespace Shell.Core
{
    partial class ShellCore : IShell
    { 
        public ShellCore() // Shellcore Constructor
        {
            this.ElmInitialized = 0;
            this.Pi = Math.PI();
            this.E = Math.E();
            this.C = 299792458;
            // This sets up ElmInitialized
        }



        // DWJHFKAHDAHSDJHADSHASDJASHSDAHJ
    }
}
