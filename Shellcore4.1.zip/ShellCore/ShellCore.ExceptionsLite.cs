﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Core
{
    partial class ShellCore // ExceptionsLite Manager methods
    {
        List<Exception> ExceptionList { get; set; } // List of exception

        // master list of exceptions
        // ExceptionsLite
        // For practice, maybe, or just doing cool things.

        internal void ElmInitExceptionManager()
        {
           ExceptionList = new List<Exception>();
           return;
        }
       
        internal int ElmRegisterException(string exceptionName, int exceptionId, string exceptionMessage, int exceptionSeverity) // internal exception registration (pseudo-constructor for Exception struct)
        {

            Exception _ = new Exception(); // create temporary struct object for configuring the exception and then add it to the list and abandon the variable forever, sending it to the orphanage in the process, where it will then proceed to being killed at the hands of the GC. Rip baby variable.
            _.exceptionName = exceptionName;
            _.exceptionId = exceptionId;
            _.exceptionMessage = exceptionMessage;
            _.exceptionSeverity = exceptionSeverity;
            ExceptionList.Add(_);
            // _ dies here
            return 0;
        }

        public int ElmRegisterExceptionP(string exceptionName, int exceptionId, string exceptionMessage, int exceptionSeverity) // public exception registration
        {
            if (exceptionId < 10000) // 10,000 and below will be used by the shell
            {
                return 1;
            }

            ElmRegisterException(exceptionName, exceptionId, exceptionMessage, exceptionSeverity);
            return 0;
        }

        internal int ElmUnregisterException(int exceptionId)
        {
            foreach (Exception _ in ExceptionList)
            {
                if (_.exceptionId == exceptionId)
                {
                    ExceptionList.Remove(_); // remove the temporary object from the list
                    return 0;
                }
            }
            return 1; // exception ID not found

        }

        public int ElmUnregisterExceptionP(int exceptionId)
        {
            if (exceptionId > 10000)
            {
                ElmUnregisterException(exceptionId);
                return 0;
            }
            return 2; // invalid exception id
        }

        public int ElmThrowException(int exceptionId) // Throws an exception.
        {
           
            foreach (Exception _ in ExceptionList )
            {
                if (_.exceptionId == exceptionId)
                {
                    // ExceptionsLite 
                    Console.WriteLine($"{_.exceptionName} #{_.exceptionId}: {_.exceptionMessage}");

                    switch (_.exceptionSeverity)
                    {
                        case 0:
                            return _.exceptionId;
                        case 1:
                            Environment.Exit(_.exceptionId); // ruh oh
                            break;
                    }
                    
                    
                }
            }
            return 0; // error: exception id not found (todo?: throw an exception)
        }

    }
    public struct Exception
    {
        public string exceptionName { get; set; } // The name of the exception.
        public int exceptionId { get; set; } // The ID of the exception. < 10000 is reserved for the shell.
        public string exceptionMessage { get; set; } // The message of the exception.
        public int exceptionSeverity { get; set; } // The severity. 0 = return from function with code exceptionId, 1 = exit with exitcode exceptionId.
    }
    // Oh Shit
}
