﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Shell.UI
{
    partial class ShellXML
    {
        // Operation code

        List<string> OperandList;

        List<char> OpList;

        string[] cleancut;

        public ShxmlVariable ShxmlPerformOperation(XmlNode token)
        {
            int count = 0;
            XmlAttributeCollection attributes = token.Attributes;
            ShxmlVariable svar = new ShxmlVariable();

            OperandList = new List<string>();
            OpList = new List<char>();

            foreach (XmlAttribute attribute in attributes)
            {
                if (attribute.Name == "op")
                {
                    //string[] thebits = attribute.Value.Split(whatwerecuttingout);
                    char[] thebits = attribute.Value.ToCharArray();

                    // This works because the first operand is after the first part of the string. Thus we get the correct operands.
                    foreach (char bit in thebits)
                    {
                       switch (bit)
                        {
                            case '+':
                            case '-':
                            case '*':
                            case '/':
                                OpList.Add(bit);
                                continue;
                        }
                        count++;
                    }

                    char[] OpListA = OpList.ToArray(); // convert to array
                    cleancut = attribute.Value.Split(OpListA);
                    
                    count = 0; // reset the count

                    foreach (string bit2 in cleancut)
                    {
                        foreach (ShxmlVariable shvar in Varlist)
                        {
                            if (cleancut[count] == shvar.Name)
                            {
                                if (shvar.Type == 1)
                                {
                                    ShellCore.ElmThrowException(14); // Can't do stuff to strings...yet. 
                                }

                                else if (shvar.Type == 5)
                                {
                                    ShellCore.ElmThrowException(15); // Can't add booleans.
                                }

                                else
                                {
                                    OperandList.Add(bit2);
                                    count++;
                                    continue;
                                }
                            }
                        
                        }
                        OperandList.Add(bit2);
                        count++;
                    }

                }

                if (attribute.Name == "var") // a
                {
                    svar.Name = attribute.Value;
                }

                count = 0; //set count back to 0

                // this actually parses the stuff
                foreach (string bit2 in cleancut)
                {
                    double result = 0; // resultint?

                    //switch (OpList[count])
                    //{
                        //case '+':
                            //List<int> bit3 = bit2.ToList();
                            //result = ShellCore.BaseMath(0, OpList.Count - 1, bit3);
                            //continue;
                        //case '-':
                            //result = result - bit2[count + 1];
                            //continue;
                        //case "*":
                            //result = result * bit2[count + 1];
                            //continue;
                        //case "/":
                            //result = result * b

                    //}

                    count++;
                }
            }

            return svar;
        }

    }
}
