﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.UI
{
    partial class ShellUI
    {
        public void ShxmlHandleIfStatement()
        {
            ShellCore.ElmThrowException(25);
            return;
        }
    }
}
